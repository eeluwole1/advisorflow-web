import { Routes } from '@angular/router';
import { ClientsPage } from './features/clients/clients-page';
import { HouseholdDetail } from './features/clients/household-detail';
import { NoSelection } from './features/clients/no-selection';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'clients' },
  {
    path: 'clients',
    component: ClientsPage,
    title: 'Clients · AdvisorFlow',
    children: [
      { path: '', component: NoSelection },
      { path: ':id', component: HouseholdDetail },
    ],
  },
  { path: '**', redirectTo: 'clients' },
];
