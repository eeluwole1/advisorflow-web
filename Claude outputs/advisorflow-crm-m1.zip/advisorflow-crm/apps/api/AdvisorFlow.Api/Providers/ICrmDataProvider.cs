using AdvisorFlow.Api.Domain;

namespace AdvisorFlow.Api.Providers;

/// <summary>
/// The boundary between the API and the CRM system of record.
/// MockCrmDataProvider serves fictional data for local development;
/// SalesforceCrmDataProvider will read from Salesforce Developer Edition (M2).
/// Implementations return null for "not found" and throw
/// <see cref="CrmUnavailableException"/> or <see cref="CrmUpstreamException"/>
/// for integration failures.
/// </summary>
public interface ICrmDataProvider
{
    Task<PagedResult<Household>> GetHouseholdsAsync(HouseholdQuery query, CancellationToken ct);

    Task<Household?> GetHouseholdAsync(string id, CancellationToken ct);

    /// <summary>Returns null when the household does not exist.</summary>
    Task<IReadOnlyList<HouseholdMember>?> GetMembersAsync(string householdId, CancellationToken ct);

    /// <summary>Member counts and primary contacts for list views, in one round trip.</summary>
    Task<IReadOnlyDictionary<string, IReadOnlyList<HouseholdMember>>> GetMembersForHouseholdsAsync(
        IReadOnlyCollection<string> householdIds, CancellationToken ct);
}

/// <summary>The CRM cannot be reached or is not configured. Maps to HTTP 503.</summary>
public sealed class CrmUnavailableException(string message, Exception? inner = null)
    : Exception(message, inner);

/// <summary>The CRM answered with an error or unusable data. Maps to HTTP 502.</summary>
public sealed class CrmUpstreamException(string message, Exception? inner = null)
    : Exception(message, inner);
