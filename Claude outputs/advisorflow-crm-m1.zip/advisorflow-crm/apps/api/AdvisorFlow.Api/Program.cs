using AdvisorFlow.Api.Providers;
using AdvisorFlow.Api.Services;

var builder = WebApplication.CreateBuilder(args);

// --- CRM provider selection -------------------------------------------------
// "Mock" (default) serves fictional in-memory data. "Salesforce" is wired in M2.
var crmProvider = builder.Configuration["Crm:Provider"] ?? "Mock";
builder.Services.Configure<SalesforceOptions>(builder.Configuration.GetSection(SalesforceOptions.SectionName));

switch (crmProvider.ToLowerInvariant())
{
    case "mock":
        builder.Services.AddSingleton<ICrmDataProvider, MockCrmDataProvider>();
        break;
    case "salesforce":
        builder.Services.AddSingleton<ICrmDataProvider, SalesforceCrmDataProvider>();
        break;
    default:
        throw new InvalidOperationException($"Unknown Crm:Provider '{crmProvider}'. Use 'Mock' or 'Salesforce'.");
}

builder.Services.AddScoped<HouseholdService>();

// --- Web API plumbing -------------------------------------------------------
builder.Services.AddControllers();
builder.Services.AddProblemDetails();
builder.Services.AddExceptionHandler<CrmExceptionHandler>();
builder.Services.AddHealthChecks();

const string FrontendCors = "Frontend";
var allowedOrigins = builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>() ?? [];
builder.Services.AddCors(options => options.AddPolicy(FrontendCors, policy => policy
    .WithOrigins(allowedOrigins)
    .WithMethods("GET")
    .AllowAnyHeader()));

var app = builder.Build();

app.UseExceptionHandler();
app.UseStatusCodePages();

if (!app.Environment.IsDevelopment())
{
    app.UseHsts();
    app.UseHttpsRedirection();
}

app.UseCors(FrontendCors);

app.MapHealthChecks("/health");
app.MapControllers();

app.Logger.LogInformation("AdvisorFlow API started with CRM provider: {Provider}", crmProvider);

app.Run();

/// <summary>Exposed so integration tests can host the API with WebApplicationFactory.</summary>
public partial class Program;
