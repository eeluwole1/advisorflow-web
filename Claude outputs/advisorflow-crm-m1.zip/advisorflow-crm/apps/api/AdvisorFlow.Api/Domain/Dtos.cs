namespace AdvisorFlow.Api.Domain;

// Stable API contract (blueprint §11.7). These DTOs are what Angular binds to,
// so the provider behind them can change without breaking the frontend.

public sealed record HouseholdSummaryDto(
    string Id,
    string Name,
    string ClientStatus,
    string? RiskProfile,
    string? Priority,
    int MemberCount,
    string? PrimaryContactName);

public sealed record HouseholdDetailDto(
    string Id,
    string Name,
    string ClientStatus,
    string? RiskProfile,
    string? Priority,
    string? Phone,
    string? AccountNumber,
    int MemberCount);

public sealed record HouseholdMemberDto(
    string Id,
    string HouseholdId,
    string FirstName,
    string LastName,
    string FullName,
    string? Email,
    string? Phone,
    string? PreferredContactMethod,
    bool IsPrimary);

public sealed record PagedResponse<T>(
    IReadOnlyList<T> Items,
    int Page,
    int PageSize,
    int TotalCount,
    int TotalPages);
