namespace AdvisorFlow.Api.Domain;

/// <summary>
/// A household is a Salesforce Account under ADR-002.
/// RiskProfile is a CRM classification tag only. It is not an investment
/// suitability assessment.
/// </summary>
public sealed record Household(
    string Id,
    string Name,
    string ClientStatus,
    string? RiskProfile,
    string? Priority,
    string? Phone,
    string? AccountNumber);

/// <summary>An individual household member, stored as a Salesforce Contact.</summary>
public sealed record HouseholdMember(
    string Id,
    string HouseholdId,
    string FirstName,
    string LastName,
    string? Email,
    string? Phone,
    string? PreferredContactMethod,
    bool IsPrimary);

/// <summary>Filter and paging options for a household list request.</summary>
public sealed record HouseholdQuery(int Page, int PageSize, string? Search, string? Status);

/// <summary>A single page of results with enough information to page further.</summary>
public sealed record PagedResult<T>(IReadOnlyList<T> Items, int Page, int PageSize, int TotalCount)
{
    public int TotalPages => PageSize == 0 ? 0 : (int)Math.Ceiling(TotalCount / (double)PageSize);
}

/// <summary>Approved values. Verify against the Salesforce picklists during M2.</summary>
public static class ClientStatuses
{
    public const string Prospect = "Prospect";
    public const string Active = "Active";
    public const string Inactive = "Inactive";

    public static readonly IReadOnlySet<string> All =
        new HashSet<string>(StringComparer.OrdinalIgnoreCase) { Prospect, Active, Inactive };
}
