# AdvisorFlow CRM

A financial advisory CRM prototype. Advisors manage **households**, their **members**, advisory **opportunities** and **follow-ups** in an Angular workspace. An ASP.NET Core API sits between the browser and **Salesforce Developer Edition**, which is the system of record.

> Portfolio prototype. All records are fictional. This is not a production system for real client financial data.

```
Angular + Tailwind (apps/web)
        │  REST / JSON
ASP.NET Core Web API (apps/api)   controllers · services · validation · authorization
        │  ICrmDataProvider
   ┌────┴─────────────┐
MockCrmDataProvider   SalesforceCrmDataProvider ── OAuth 2.0 (server-side) ──► Salesforce DE
(local development)   (milestone M2)
```

Azure (Static Web Apps + App Service, Key Vault, Application Insights) hosts the deployed version from milestone M7. Until then everything runs locally at no cloud cost.

## Current status: milestone M1, Foundation

| Works now | Comes next |
|---|---|
| Clients page: household list with search, status filter and paging | M2: retrieve Salesforce metadata, OAuth, Salesforce provider |
| Household detail with members, primary member first | M3: create/update households and members |
| API: `/health`, `/api/households`, `/{id}`, `/{id}/contacts` | M4–M6: opportunities, follow-up Flows, dashboards |
| 400 / 404 / 502 / 503 problem responses | M7: Azure deployment |
| xUnit + Vitest tests, GitHub Actions CI | |

## Run it locally

**Prerequisites:** .NET SDK 10, Node.js 22+, Git. Salesforce CLI (`sf`) is needed from M2.

```bash
# Terminal 1 — API on http://localhost:5080 (mock provider)
dotnet run --project apps/api/AdvisorFlow.Api --launch-profile http

# Terminal 2 — Angular on http://localhost:4200 (proxies /api to the API)
cd apps/web
npm install
npm start
```

Open http://localhost:4200.

### Tests

```bash
dotnet test AdvisorFlow.slnx                 # API: xUnit unit + HTTP integration tests
cd apps/web && npx ng test --watch=false     # Web: Vitest component tests
```

### Switching the data provider

`Crm:Provider` in `apps/api/AdvisorFlow.Api/appsettings.json` chooses the provider: `Mock` (default) or `Salesforce`. Salesforce credentials are never stored in appsettings. Locally they go in `dotnet user-secrets`, and in Azure they go in Key Vault. Until M2 is implemented, the Salesforce provider returns `503` and never serves fake data.

## Repository layout

```
apps/web/                    Angular 22 + Tailwind CSS 4
apps/api/AdvisorFlow.Api/    ASP.NET Core Web API (.NET 10)
tests/AdvisorFlow.Api.Tests/ xUnit tests
force-app/main/default/      Salesforce metadata (filled by the M2 baseline retrieval)
manifest/                    Salesforce retrieval manifests
scripts/                     Helper scripts (baseline retrieval)
docs/                        Requirements, ADRs, API contract, testing, runbooks
.github/workflows/ci.yml     Build and test both apps on every push / PR
```

## Documentation

- [Architecture decisions](docs/architecture/decisions.md): ADR-001 to ADR-004
- [API contract](docs/api/api-contracts.md)
- [Business rules and implementation status](docs/requirements/business-rules.md)
- [Salesforce baseline and household migration runbook](docs/deployment/salesforce-baseline-runbook.md)
- [M1 test evidence](docs/testing/m1-test-evidence.md)
- Project blueprint v1.2: `docs/requirements/AdvisorFlow_CRM_Project_Blueprint_v1.2.docx`
